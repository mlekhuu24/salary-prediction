# Salary Prediction Based on Skills/Experience
# Tools: Python, Pandas, Matplotlib, Scikit-learn

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Load dataset
data = pd.read_csv("salary_data.csv")

print("First 5 rows:")
print(data.head())

print("\nDataset shape:", data.shape)

print("\nMissing values before cleaning:")
print(data.isnull().sum())

# Features and target
X = data.drop(columns=["employee_id", "salary"])
y = data["salary"]

numeric_features = [
    "years_experience",
    "python_skill",
    "sql_skill",
    "cloud_skill",
    "communication_skill"
]
categorical_features = ["education", "job_role"]

# Preprocessing
numeric_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler())
])

categorical_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("encoder", OneHotEncoder(handle_unknown="ignore"))
])

preprocessor = ColumnTransformer([
    ("num", numeric_pipeline, numeric_features),
    ("cat", categorical_pipeline, categorical_features)
])

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Regression model
model = Pipeline([
    ("preprocessor", preprocessor),
    ("regressor", LinearRegression())
])

# Train
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# Evaluation
mae = mean_absolute_error(y_test, y_pred)
rmse = mean_squared_error(y_test, y_pred) ** 0.5
r2 = r2_score(y_test, y_pred)

print(f"\nMean Absolute Error (MAE): {mae:,.2f}")
print(f"Root Mean Squared Error (RMSE): {rmse:,.2f}")
print(f"R² Score: {r2:.4f}")

# Compare actual and predicted salaries
comparison = pd.DataFrame({
    "Actual Salary": y_test.values,
    "Predicted Salary": y_pred.round(2)
})

print("\nActual vs Predicted Salaries:")
print(comparison.head(10))

# Predict salary for a new employee
new_employee = pd.DataFrame([{
    "years_experience": 5,
    "education": "Master",
    "job_role": "Software Engineer",
    "python_skill": 8,
    "sql_skill": 7,
    "cloud_skill": 6,
    "communication_skill": 8
}])

predicted_salary = model.predict(new_employee)[0]
print(f"\nPredicted Salary: {predicted_salary:,.2f}")

# Feature impact using regression coefficients
feature_names = model.named_steps["preprocessor"].get_feature_names_out()
coefficients = model.named_steps["regressor"].coef_

importance = pd.DataFrame({
    "feature": feature_names,
    "coefficient": coefficients,
    "absolute_impact": abs(coefficients)
}).sort_values("absolute_impact", ascending=False)

print("\nTop Factors Affecting Salary:")
print(importance.head(12)[["feature", "coefficient"]])

# Visualization 1: experience vs salary
plt.figure(figsize=(8, 5))
plt.scatter(data["years_experience"], data["salary"], alpha=0.6)
plt.xlabel("Years of Experience")
plt.ylabel("Salary")
plt.title("Years of Experience vs Salary")
plt.tight_layout()
plt.savefig("experience_vs_salary.png", dpi=150)
plt.show()

# Visualization 2: actual vs predicted
plt.figure(figsize=(8, 5))
plt.scatter(y_test, y_pred, alpha=0.6)
plt.xlabel("Actual Salary")
plt.ylabel("Predicted Salary")
plt.title("Actual vs Predicted Salaries")
plt.tight_layout()
plt.savefig("actual_vs_predicted.png", dpi=150)
plt.show()

# Visualization 3: average salary by education
education_salary = data.groupby(
    "education", dropna=False
)["salary"].mean()

plt.figure(figsize=(8, 5))
education_salary.plot(kind="bar")
plt.xlabel("Education")
plt.ylabel("Average Salary")
plt.title("Average Salary by Education Level")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("education_vs_salary.png", dpi=150)
plt.show()
