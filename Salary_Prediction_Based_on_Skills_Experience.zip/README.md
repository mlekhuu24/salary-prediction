# Salary Prediction Based on Skills/Experience

## Synopsis
This project focuses on predicting an employee's salary based on factors such as years of experience, education, job role, and technical skills. Students analyze the relationship between experience, skills, and salary and build a machine learning model to estimate expected salary.

## Objectives
- Analyze employee salary data.
- Study the relationship between experience and salary.
- Identify important salary-related factors.
- Train a regression model.
- Predict expected salary.
- Compare predicted and actual salaries.

## Tools
Python, Pandas, Matplotlib, Scikit-learn

## Dataset Features
- employee_id
- years_experience
- education
- job_role
- python_skill
- sql_skill
- cloud_skill
- communication_skill
- salary

Target:
- salary — predicted employee salary

## Data Preparation
- Loaded employee salary data using Pandas.
- Checked for missing values.
- Filled missing numerical values using median values.
- Filled missing categorical values using the most frequent value.
- Standardized numerical features.
- One-hot encoded categorical features.
- Split the dataset into training and testing sets.

## Machine Learning Algorithm
Linear Regression is used as the regression model.

## Evaluation
The program calculates:
- Mean Absolute Error (MAE)
- Root Mean Squared Error (RMSE)
- R² Score
- Actual vs predicted salary comparison
- Predicted salary for a new employee
- Important salary-related factors based on regression coefficients

It also generates:
- `experience_vs_salary.png`
- `actual_vs_predicted.png`
- `education_vs_salary.png`

## How to Run
1. Install Python.
2. Open a terminal in this project folder.
3. Install dependencies:
   pip install -r requirements.txt
4. Run:
   python salary_prediction.py

## Dataset Note
The included salary dataset is synthetic and intended for educational/classroom machine-learning practice. It does not contain real employee compensation records.
